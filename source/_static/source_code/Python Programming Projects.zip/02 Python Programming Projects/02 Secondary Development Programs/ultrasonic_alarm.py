import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Create IIC1 object
i2c1 = Hiwonder_IIC.IIC(1)
# Create glowing ultrasonic object
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)
# Create buzzer object
beep = Hiwonder.Buzzer()

# Ultrasonic distance measurement
distance = 0

# Set MechDog initial posture
mechdog.set_default_pose()
# Delay function, parameter is the delay time (unit: seconds)
time.sleep(1)


# Main function
def main():
  global distance

  while True:
    # Get distance measured by glowing ultrasonic
    distance = i2csonar.getDistance()
    # If distance is less than 10 cm
    if (distance<10):
      # Glowing ultrasonic color setting function
      # Parameter 1: Set light, 0 to set both lights, 1 to set light 1, 2 to set light 2；
      # Parameters 2, 3, 4: Correspond to red, green, and blue color values
      i2csonar.setRGB(0,255,0,0) # Set to red
    else:
      if (distance>50):
        i2csonar.setRGB(0,0,255,0) # Set to green
      else:
        i2csonar.setRGB(0,(250-((round(distance))*5)),((round(distance))*5),0) # Set red and green colors based on distance
    time.sleep(0.1)

# Buzzer sounding function
def start_main1():
  global distance

  while True:
    # When distance is less than 50 cm, sound according to distance
    if (distance<=50):
      beep.playTone(800,100,True)
      time.sleep((distance/50))
    else:
      time.sleep(50)

# Register buzzer sounding thread
Hiwonder.startMain(start_main1)
# Execute main function
main()
