import network
import socket
import time
import machine
import Hiwonder
from HW_MechDog import MechDog

'''
  MechDog群控，操作步骤如下：
  1、需要提供一个wifi；
  2、修改该程序的wifi名和密码，并下载到需要群控的MechDog中；
  3、手机连接同一个wifi，并打开MechDog群控APP，即可搜索控制。
'''

SSID = "hiwonder"       #WiFi名称
PASSWORD = "hiwonder"   #WiFi密码

'''********************************************* GROUP_CTL *********************************************'''
class GROUP_CTL():
  __PORT = 9027  #  #wlan
  def __init__(self,ssid , password):
    mac = machine.unique_id()
    self.mac_str = "".join("{:02X}".format(b) for b in mac)
    self.ssid = ssid
    self.password = password
    self.port = self.__PORT
    self.buffer = bytearray()
    self.max_buffer_size = 50
    self.rec_addr = None
    
    self.connectWifi(self.ssid , self.password)
    self.ip = wlan.ifconfig()[0]
    self.listenSocket=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    self.listenSocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    self.listenSocket.bind((self.ip,self.port))  #绑定ng...'
    while True:
      if  wlan.isconnected() == True: # 连接成功
        print('connect ok!')
        break
      time.sleep(0.1)
    Hiwonder.startMain(self.__loop)

  def read_data(self):
    data,addr=self.listenSocket.recvfrom(1024)
    self.rec_addr = addr[0]
    return data

  def connectWifi(self,ssid,passwd):
    global wlan
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)   #激活网络
    wlan.disconnect()   #断开WiFi连接
    wlan.connect(ssid, passwd)   #连ifconfig()[0] == '0.0.0.0'):   #等待连接
    time.sleep(1)
    return True

  def __loop(self):
    while True:
      data = self.read_data()
      self.buffer.extend(data)
      # 如果缓冲区大小超过最大限制，则丢弃旧数据
      if len(self.buffer) > self.max_buffer_size:
        self.buffer = self.buffer[self.max_buffer_size - 20:]
      time.sleep(0.05)

  def send_ID(self):
    if self.rec_addr:
      self.listenSocket.sendto("GROUP|MechDog{}|END".format(self.mac_str),(self.rec_addr,9025))

  def contains_data(self, value):
    return value in self.buffer

  # 从缓冲区中读取从 "CMD" 到 "$" 之间的字符并返回该值，并将已读取的数据从缓冲区中删除
  def read_uart_cmd(self):
    start_index = 0
    while True:
      index = self.buffer.find(b'CMD', start_index+1)  # 查找 "CMD" 的起始位置
      if index < 0:
        break
      start_index = index
    end_index = self.buffer.find(b'$', start_index)  # 查找 "$" 的位置，从 "CMD" 后开始搜索
    if start_index != -1 and end_index != -1:
      cmd_data = self.buffer[start_index:end_index+1]  # 提取 "CMD" 到 "$" 之间的字符 +1
      self.buffer = self.buffer[end_index + 1:]  # 删除已读取的数据
      return cmd_data.decode('utf-8')  # 将字节数组解码为字符串
    else:
      return None
  
  # 解析命令并返回参数列表
  def parse_uart_cmd(self, cmd_str):
    parts = cmd_str.split('|')  # 使用 '|' 分割命令字符串
    return parts[1:-1]  # 返回除了命令类型以外的所有部分

'''********************************************* GROUP_CTL *********************************************'''

_RUN_STEP = 0
_ACTION_TYPE = 0
_ACTION_NUM = 0 

group = GROUP_CTL(SSID,PASSWORD)
mechdog = MechDog()
time.sleep(1)

def main1():
  global _RUN_STEP
  global _ACTION_TYPE
  global _ACTION_NUM
  
  _BLE_REC_DATA = 0
  while True:
    try:
      if group.contains_data("CMD"):
        _BLE_REC_DATA = group.read_uart_cmd()
        if not _BLE_REC_DATA:
          continue
        _REC_PARSE_VALUE = group.parse_uart_cmd(_BLE_REC_DATA)
        _COMMAND = _REC_PARSE_VALUE[0]
        _COMMAND = int(_COMMAND)
        if _COMMAND == 0:
          group.send_ID()
        elif _COMMAND == 2:
          _RUN_STEP = 2
          _ACTION_TYPE = int(_REC_PARSE_VALUE[1])
          _ACTION_NUM = int(_REC_PARSE_VALUE[2])
      time.sleep(0.05)
    except:
      pass


def main2():
  global _RUN_STEP
  step = 0
  while True:
    if (step==0):
      step = _RUN_STEP
      _RUN_STEP = 0
      time.sleep(0.05)
    else:
      if step == 2:
        if (_ACTION_TYPE==1):
          mechdog.set_default_pose(duration = 500)
          time.sleep(0.6)
          dong_zuo_zu_yun_xing(_ACTION_NUM)
        else:
          mechdog.set_default_pose(duration = 500)
          time.sleep(0.6)
          mechdog.action_run(str(_ACTION_NUM))
        _RUN_STEP = 0
        step = 0


def dong_zuo_zu_yun_xing(dong_zuo):
  global mechdog
  if (dong_zuo==1):
    mechdog.action_run("left_foot_kick")
    time.sleep(3)
    return
  if (dong_zuo==2):
    mechdog.action_run("right_foot_kick")
    time.sleep(3)
    return
  if (dong_zuo==3):
    mechdog.action_run("stand_four_legs")
    time.sleep(2)
    return
  if (dong_zuo==4):
    mechdog.action_run("sit_dowm")
    time.sleep(2)
    return
  if (dong_zuo==5):
    mechdog.action_run("go_prone")
    time.sleep(2)
    return
  if (dong_zuo==6):
    mechdog.action_run("stand_two_legs")
    time.sleep(4)
    return
  if (dong_zuo==7):
    mechdog.action_run("handshake")
    time.sleep(4)
    return
  if (dong_zuo==8):
    mechdog.action_run("scrape_a_bow")
    time.sleep(4)
    return
  if (dong_zuo==9):
    mechdog.action_run("nodding_motion")
    time.sleep(2)
    return
  if (dong_zuo==10):
    mechdog.action_run("boxing")
    time.sleep(2)
    return
  if (dong_zuo==11):
    mechdog.action_run("stretch_oneself")
    time.sleep(2)
    return
  if (dong_zuo==12):
    mechdog.action_run("pee")
    time.sleep(2)
    return
  if (dong_zuo==13):
    mechdog.action_run("press_up")
    time.sleep(2)
    return
  if (dong_zuo==14):
    mechdog.action_run("rotation_pitch")
    time.sleep(2)
    return
  if (dong_zuo==15):
    mechdog.action_run("rotation_roll")
    time.sleep(2)
    return

Hiwonder.startMain(main1)
Hiwonder.startMain(main2)

