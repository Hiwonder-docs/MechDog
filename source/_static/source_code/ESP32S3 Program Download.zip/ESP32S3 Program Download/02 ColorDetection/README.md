# 颜色识别IIC寄存器(color recognition I2C register instruction)

## 设备地址：0x52(device address: 0x52)



- ### 颜色识别(color recognition)

  | 寄存器地址(register address) |                   数据格式(data format): unsigned char                    |
  | :--------: | :----------------------------------------------------------: |
  |    0x00    | data[0]:红色中心X轴坐标(X-axis coordinate of red center)<br/>data[1]:红色中心Y轴坐标(Y-axis coordinate of red center)<br/>data[2]:红色检测框宽度(width of red detection box)<br/>data[3]:红色检测框长度(length of red detection box)<br/> |
  |    0x01    | data[0]:蓝色中心X轴坐标(X-axis coordinate of blue center)<br/>data[1]:蓝色中心Y轴坐标(Y-axis coordinate of blue center)<br/>data[2]:蓝色检测框宽度(width of blue detection box)<br/>data[3]:蓝色检测框长度(length of blue detection box)<br/> |
  
  
  
  