import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()

# Main function
def main():
  # Delay function, with the parameter being the delay time (unit: seconds)
  time.sleep(2)
  # move()
  # Parameter 1: Step length (unit: mm) (positive value for forward, negative value for backward)
  # Parameter 2: Turning angle (unit: degrees), positive value for left turn, negative value for right turn
  mechdog.move(80,0)
  time.sleep(5)
  mechdog.move(0,0)
  time.sleep(2)
  mechdog.move(-50,0)
  time.sleep(5)
  # Stop
  mechdog.move(0,0)
  time.sleep(2)

# Run the main function
main()

