import Hiwonder
import time
from HW_MechDog import MechDog

# Button press flag
enter_flag = 0
# Initial speed value
speed = 40

# Initialize MechDog object  
mechdog = MechDog()
# Button object
button1 = Hiwonder.Button(1)

# Delay function with the parameter as delay time (in seconds)
time.sleep(1)


# Main function
def main():
  global enter_flag
  while True:
    if (enter_flag==1):
      if (speed==40):
        mechdog.move(speed,0)
        time.sleep(10)
        speed = 60
      elif (speed==60):
        mechdog.move(speed,0)
        time.sleep(10)
        speed = 80
      else:
        mechdog.move(speed,0)
        time.sleep(10)
        speed = 40
      # Stop
      mechdog.move(0,0)
      enter_flag = 0
      
    time.sleep(0.05)

# Function called on short button press
def on_button1_clicked():
  global enter_flag
  enter_flag = 1

# Register short button press function
button1.Clicked(on_button1_clicked)

# Execute main function
main()

