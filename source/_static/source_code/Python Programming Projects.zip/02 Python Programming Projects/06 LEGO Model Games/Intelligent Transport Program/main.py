import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Initialize the tipping bucket
mechdog.set_servo(9,1600,50)

# Main function 
def main():
  # Delay function: the parameter is the delay time in seconds
  time.sleep(2)
  # "move()" function
  # Parameter 1: stride (unit: mm); If it is a positive value, the robot moves forward. If it is a negative value, the robot moves backward.
  # unit: degrees); If it is a positive value, the robot turns left. If it is a negative value, the robot turns right.
  mechdog.move(120,0)
  time.sleep(3)
  mechdog.move(0,0)
  time.sleep(0.5)
  mechdog.action_run("sit_dowm")
  time.sleep(1)
  mechdog.set_servo(9,1450,300)
  time.sleep(1.5)
  mechdog.set_servo(9,1600,300)
  time.sleep(0.5)
  mechdog.set_default_pose()

# Execute the main function
main()

