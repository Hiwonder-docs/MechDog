from HW_MechDog import MechDog
import Hiwonder
import Hiwonder_IIC
from time import sleep_ms

act_name_list = ["left_foot_kick","right_foot_kick","stand_four_legs",
                  "sit_dowm","go_prone","stand_two_legs","handshake","scrape_a_bow",
                  "nodding_motion","boxing","stretch_oneself","pee","press_up",
                  "rotation_pitch","rotation_roll"]


dog = MechDog(duration = 1000)
iic = Hiwonder_IIC.IIC(2,mode=1)
iic.begin()
iic1 = Hiwonder_IIC.IIC(1)

sonar = Hiwonder_IIC.I2CSonar(iic1)
sleep_ms(1000)
dog.set_pose([-5,0,0],[0,0,0],100)
sleep_ms(100)

run_state = 0
data = []


def iic_rec():
  global dog
  global run_state
  global data
  
  power_count = 0
  
  while True:
    if iic.is_change():
      change_flag = iic.get_change()
      for i in change_flag:
        if i != 0:
          rec = iic.get_reg_value(i)
          if i == 1:
            run_state = 1
          elif i == 2:
            run_state = 2
            data = rec
          elif i == 4:
            run_state = 4
            data = rec
          elif i == 6:
            run_state = 6
            data = rec
          elif i == 7:
            run_state = 7
            data = rec
          elif i == 8:
              run_state = 8
        else:
          break
    power_count += 1
    if power_count >= 4:
      power_count = 0
      iic.set_power_value(Hiwonder.Battery_power())
      iic.set_Sonar_distance((int)(sonar.getDistance()*10))
    sleep_ms(20)


def run():
  global run_state
  global data
  
  step = 0
  roll = 0
  pitch = 0
  while True:
    try:
      if step == 0:
        if run_state == 1:
          step = 1
          run_state = 0
        elif run_state == 2:
          step = 2
          run_state = 0
        elif run_state == 4:
          step = 4
          run_state = 0
        elif run_state == 6:
          step = 6
        elif run_state == 7:
          step = 7
          run_state = 0
        elif run_state == 8:
          run_state = 0
        sleep_ms(20)
      elif step == 1:
        roll = 0
        pitch = 0
        dog.set_pose([-5,0,0],[0,0,0],500)
        sleep_ms(500)
        step = 0
      elif step == 2:
        pitch = pitch + data[0]
        if pitch >= 20:
          pitch = 20
        elif pitch <= -20:
          pitch = -20
        dog.set_pose([-5, 0, 0], [roll,pitch, 0], data[1])
        # dog.transform([0, 0, 0], [ 0,data[0], 0], data[1])
        sleep_ms(data[1])
        step = 0
      elif step == 4:
        roll = roll + data[0]
        if roll >= 20:
          roll = 20
        elif roll <= -20:
          roll = -20
        # dog.transform([0, 0, 0], [data[0],0, 0], data[1])
        dog.set_pose([-5, 0, 0], [roll,pitch, 0], data[1])
        sleep_ms(data[1])
        step = 0
      
      elif step == 6:
        if run_state == 6:
          run_state = 0
          dog.move(data[0],data[1])
          if data[0] == 0 and data[1] == 0:
            step = 0
      
      elif step == 7:
        roll = 0
        pitch = 0
        if data[0] > 0:
          if data[0] <= 15:
            dog.action_run(act_name_list[data[0]-1])
        elif data[1] > 0:
          num = "{}".format(data[1])
          dog.action_run(num)
        sleep_ms(100)
        while not dog.action_is_over():
          if run_state == 8:
            dog.stop_action()
          sleep_ms(50)
        step = 0
        run_state = 0
    except:
      print("error")

Hiwonder.startMain(iic_rec)
Hiwonder.startMain(run)












