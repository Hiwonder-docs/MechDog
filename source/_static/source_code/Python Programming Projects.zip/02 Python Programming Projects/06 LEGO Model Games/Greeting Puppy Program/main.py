import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

'''
  Face recognition -> wag the tail
'''

iic2 = Hiwonder_IIC.IIC(2)
cam = Hiwonder_IIC.ESP32S3Cam(iic2)
mechdog = MechDog()
time.sleep(2)
mechdog.set_servo(9,1500,50) # Set the tail to its neutral position
time.sleep(0.5)
mechdog.action_run("sit_dowm") # Execute the action of sitting down
time.sleep(2)


while True:
  ret = cam.face_recognition()
  if ret:
    mechdog.set_servo(9,1300,20)
    time.sleep(0.07)
    mechdog.set_servo(9,1700,20)
    time.sleep(0.07)
  else:
    mechdog.set_servo(9,1500,50)
    time.sleep(0.05)
  
  time.sleep(0.1)



