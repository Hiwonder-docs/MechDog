import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Create I2C1 object
i2c1 = Hiwonder_IIC.IIC(1)
# Create glowy ultrasonic sensor object
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)
# Create dot matrix object
tm = Hiwonder.Digitaltube()

# Ultrasonic ranging
distance = 0
position = 1500

# Set the brightness of the dot matrix to 4
tm.setBrightness(4)
# Set MechDog to its initial posture
mechdog.set_default_pose()
# Delay function: the parameter is the delay time in seconds
time.sleep(1)


# Main function
def main():
  global distance

  while True:
    # Obtain the distance detected by the ultrasonic sensor
    distance = i2csonar.getDistance()
    # The distance is displayed on the dot matrix
    tm.showNum(distance)
    # If the distance is less than 10cm
    if (distance<10):
      # Function for setting the color of the ultrasonic sensor
      # Parameter 1: the number of the set light; 0: set 2 lights; 1: set 1 light; 2: set 2 lights
      # Parameters 2 to 4 corresponds the values of red, green, and blue respectively
      i2csonar.setRGB(0,255,0,0) # set to red
    else:
      if (distance>50):
        i2csonar.setRGB(0,0,255,0) # set to green
      else:
        i2csonar.setRGB(0,(250-((round(distance))*5)),((round(distance))*5),0) # Set red and green based on the detected distance
    time.sleep(0.1)

# Wing flapping function
def start_main1():
  global distance

  while True:
    # If the detected distance is less than 50cm, control the wings to flap based on the distance
    if (distance<=50):
      servo_position(100)
      time.sleep((distance if distance>6 else 5)/50)
      servo_position(-100)
      time.sleep((distance if distance>6 else 5)/50)
      servo_position(100)
      
def servo_position(pos):
  mechdog.set_servo(9,position-pos,5)
  mechdog.set_servo(10,position+pos,5)

# Register the wing flapping thread
Hiwonder.startMain(start_main1)
# Execute the main function
main()


