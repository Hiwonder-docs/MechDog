import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize the MechDog object
mechdog = MechDog()


# Set the initial posture of MechDog
mechdog.set_default_pose()
# Delay function, with the parameter being the delay time (unit: seconds)
time.sleep(2)
# Set the step length to be very small (1 mm), approximating stepping in place
mechdog.move(1,0)
time.sleep(10)
# Stop
mechdog.move(0,0)
