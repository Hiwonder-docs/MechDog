#include "Wire.h"
#ifndef HIWONDER_H
#define HIWONDER_H

#include <Arduino.h>

#define Freq_default 1000
#define Channel_default 11
#define Pin_default 21
#define Key_Pin 5
#define Touch_Pin 33
#define Led_Pin 18
#define SCL1 23
#define SDA1 22
#define SCL2 13
#define SDA2 19

/* Ultrasound */
#define ULTRASOUND_I2C_ADDR 0x77  //I2C address of the ultrasonic module with RGB lighting
#define DISTANCE_ADDR 0
#define DISDENCE_L    0
#define DISDENCE_H    1
#define RGB_WORK_MODE 2//RGB light mode: 0 = custom mode, 1 = breathing light mode (default: 0)
#define RGB1_R      3//Red value for sensor 1 (0–255, default: 0)
#define RGB1_G      4//Green value for sensor 1 (default: 0)
#define RGB1_B      5//Blue value for sensor 1 (default: 255)
#define RGB2_R      6//Red value for sensor 2 (0–255, default: 0)
#define RGB2_G      7//Green value for sensor 2 (default: 0)
#define RGB2_B      8//Blue value for sensor 2 (default: 255)
#define RGB1_R_BREATHING_CYCLE      9 //Breathing cycle for red on sensor 1 (unit: 100ms, default: 0)
#define RGB1_G_BREATHING_CYCLE      10
#define RGB1_B_BREATHING_CYCLE      11
#define RGB2_R_BREATHING_CYCLE      12//Breathing cycle for red on sensor 2
#define RGB2_G_BREATHING_CYCLE      13
#define RGB2_B_BREATHING_CYCLE      14
#define RGB_WORK_SIMPLE_MODE    0 //Simple (static) light mode
#define RGB_WORK_BREATHING_MODE   1 //Breathing light mode
#define FILTER_N 3
#define DISTANCE_ERRO 65535

/* ASRSensor */
#define ASR_I2C_ADDR		0x79 //I2C address of the voice recognition module
#define ASR_RESULT_ADDR           100
//ontinuously read this address to check if a voice command is recognized. Different values correspond to different recognized voice commands.
#define ASR_WORDS_ERASE_ADDR      101//Address to erase all stored voice commands
#define ASR_MODE_ADDR             102
//Recognition mode settings
//1: Continuous recognition mode. Status LED stays on. (default mode)    
//2: Wake-word mode. The first entry acts as a wake word. LED is off by default. Turns on when wake word is recognized, waits for a new command, then turns off after result is read.
//3：Button-triggered mode. Recognition starts only when a button is pressed. Supports power-off memory. LED is on while button is pressed.
#define ASR_ADD_WORDS_ADDR        160//Address to add new voice commands, supports power-off memory

/* MP3Sensor */
#define MP3_I2C_ADDR    0x7B //I2C address of the MP3 module
#define MP3_PLAY_NUM_ADDR         1//Play a specific track (range: 0–3000), low byte first, high byte second
#define MP3_PLAY_ADDR             5//Play command
#define MP3_PAUSE_ADDR            6//Pause command
#define MP3_PREV_ADDR             8//Play previous track
#define MP3_NEXT_ADDR             9//Play next track
#define MP3_VOL_VALUE_ADDR        12//Set volume level (range: 0–30)
#define MP3_SINGLE_LOOP_ON_ADDR   13//Enable single-track repeat (must be set during playback to take effect)
#define MP3_SINGLE_LOOP_OFF_ADDR  14//Disable single-track repeat
#define MP3_MAXCOUNT  3001

#define ESP32S3_IIC_ADDR 0x53
#define RED 0
#define YELLOW 1
#define GREEN 2
#define BLUE 3
#define BLACK 4
#define FACE_CENTER_ADDR 0xB0
#define COLOR_ADDR 0xC5
#define COLOR_FOLLOW_ADDR 0xC0
#define Line_FOLLOW_UP_ADDR 0xA0
#define Line_FOLLOW_DOWN_ADDR 0xA1

#define Echo_ADDR                0x34
//Address for recognition results. Continuously read this address to determine. If a voice command has been recognized. Different values correspond to different commands.
#define Echo_RESULT_ADDR   0x64
#define Echo_SPEAK_ADDR    0x6E

#define Echo_CMDMAND    0x00
#define Echo_ANNOUNCER  0xFF

static int filter_buf[FILTER_N + 1];
typedef void (*CallbackFunc)();

bool wireWriteByte(TwoWire *iic, uint8_t addr, uint8_t val);
bool wireWriteDataArray(TwoWire *iic, uint8_t addr, uint8_t reg,uint8_t *val,unsigned int len);
int wireReadDataArray(TwoWire *iic, uint8_t addr, uint8_t reg, uint8_t *val, unsigned int len);
bool wireWriteWords(TwoWire *iic, uint8_t addr, uint8_t reg,uint8_t idNum,unsigned char *words);

void taskRun(void *p);
void startMain(CallbackFunc ncb);

extern TwoWire IIC1;
extern TwoWire IIC2;

class PowerBuzzer{
  private:
    int Buzzer_freq;
    int Buzzer_channel;
    int Buzzer_Pin;
    int BatteryValue;
    int duty_value;
    int time_value;
    bool bt_open;
    bool bt_state;
    bool duty_flag;
    bool userTone;
    TaskHandle_t Battery_TaskHandel;
    static void Buzzer_Task(void *p);
  
  protected:
    void Buzzer_init(void);

  public:
    PowerBuzzer(void){
      Buzzer_freq = Freq_default; 
      Buzzer_channel = Channel_default; 
      Buzzer_Pin = Pin_default;
      bt_open = true;
      bt_state = false;
      duty_flag = false;
      userTone = false;
      Battery_TaskHandel = NULL;
    };
    
    void playTone(int duty, int btime, bool bg_State);
    void setVolume(int freq);
    int readBattery(void);
    void disableLowPowerAlarm(void);
};

class Button{
  private:
    int bt_key;
    bool clicked_state;
    CallbackFunc clicked_cb;
    CallbackFunc longpressed_cb;
    TaskHandle_t Button_TaskHandel;
    static void Button_Task(void *p);
  public:
    Button(void){
      bt_key = 0;
      clicked_state = false;
      clicked_cb = nullptr;
      longpressed_cb = nullptr;
      Button_TaskHandel = NULL;
    };
    int GetButtonResult(void);
    void Button_init(uint8_t num = 1); 
    void Clicked(CallbackFunc ncb);
    void Longpressed(CallbackFunc ncb);
};

class LED{
  public:
    void LED_init(void);
    void on(void);
    void off(void);
};

class LightSensor{
  public:
    int read(void);
};

class UltrasoundSonar{
  public:
    void Ultrasound_init(void);
    void setRGB(uint8_t index, uint8_t r, uint8_t g, uint8_t b);
    void setBreathing(uint8_t index, uint8_t rgb, uint8_t cycle);
    uint16_t getDistance(void);
};

class ASRSensor{
  public:
    void ASR_init(void);
    void setMode(uint8_t mode);
    void addWord(uint8_t idNum, const char *words);
    void erase(void);
    uint8_t getResult(void);
};

class MP3Sensor{
  public:
    void MP3_init(void);
    void play(uint16_t num = MP3_MAXCOUNT);
    void pause(void);
    void prev(void);
    void next(void);
    void loop_on(void);
    void loop_off(void);
    void volume(uint8_t value);
};

class ESP32S3Cam{
  public:
    void ESP32S3_init();
    bool face_recognition();
    void color_recognition(uint8_t *color_data);
    void color_follow(uint8_t color_label, uint8_t *color);
    void line_follow(uint8_t line_num, uint8_t *line);
};

class ASR_MOUDLE{
  public:
    ASR_MOUDLE(void);
    void begin();
    uint8_t rec_recognition(void);
    void speak(uint8_t cmd , uint8_t id);

  private:
    uint8_t send[2];
};

#endif  //HIWONDER_H
