#include "iic_data_send.hpp"
#include "Wire.h"

#define I2C_SLAVE_ADDRESS 0x53

static QueueHandle_t xQueueResultI = NULL;
static QueueHandle_t xQueueResultO = NULL;

static const char *TAG = "iic_data_send";
static const int sdaPin = 47;
static const int sclPin = 48;
static const uint32_t i2cFrequency = 100000;

static send_color_data_t send_color_data;

static uint8_t rec = 0xFF;
static uint8_t send_data[7] = {0};

static void iic_receive(int len)
{
  while(Wire.available())
  {
    rec = Wire.read();
  }  
}

static void iic_request()
{
    switch(rec)
    {
    /* 红色色块数据 */
    case 0xA0:
      if((send_color_data.segment1[0].right_down_x - send_color_data.segment1[0].left_up_x) > 0){
        send_data[0] = send_color_data.segment1[0].id;
        send_data[1] = send_color_data.segment1[0].left_up_x;
        send_data[2] = send_color_data.segment1[0].left_up_y;
        send_data[3] = send_color_data.segment1[0].right_down_x;
        send_data[4] = send_color_data.segment1[0].right_down_y;
        send_data[5] = send_color_data.segment1[0].center_x;
        send_data[6] = send_color_data.segment1[0].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }   
      break;
    case 0xA1:
      if((send_color_data.segment2[0].right_down_x - send_color_data.segment2[0].left_up_x) > 0){
        send_data[0] = send_color_data.segment2[0].id;
        send_data[1] = send_color_data.segment2[0].left_up_x;
        send_data[2] = send_color_data.segment2[0].left_up_y;
        send_data[3] = send_color_data.segment2[0].right_down_x;
        send_data[4] = send_color_data.segment2[0].right_down_y;
        send_data[5] = send_color_data.segment2[0].center_x;
        send_data[6] = send_color_data.segment2[0].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }      
      break;

    /* 黄色色块数据 */
    case 0xA2:
      if((send_color_data.segment1[1].right_down_x - send_color_data.segment1[1].left_up_x) > 0){
        send_data[0] = send_color_data.segment1[1].id;
        send_data[1] = send_color_data.segment1[1].left_up_x;
        send_data[2] = send_color_data.segment1[1].left_up_y;
        send_data[3] = send_color_data.segment1[1].right_down_x;
        send_data[4] = send_color_data.segment1[1].right_down_y;
        send_data[5] = send_color_data.segment1[1].center_x;
        send_data[6] = send_color_data.segment1[1].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }      
      break;
    case 0xA3:
      if((send_color_data.segment2[1].right_down_x - send_color_data.segment2[1].left_up_x) > 0){
        send_data[0] = send_color_data.segment2[1].id;
        send_data[1] = send_color_data.segment2[1].left_up_x;
        send_data[2] = send_color_data.segment2[1].left_up_y;
        send_data[3] = send_color_data.segment2[1].right_down_x;
        send_data[4] = send_color_data.segment2[1].right_down_y;
        send_data[5] = send_color_data.segment2[1].center_x;
        send_data[6] = send_color_data.segment2[1].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }       
      break;

    /* 绿色色块数据 */
    case 0xA4:
      if((send_color_data.segment1[2].right_down_x - send_color_data.segment1[2].left_up_x) > 0){
        send_data[0] = send_color_data.segment1[2].id;
        send_data[1] = send_color_data.segment1[2].left_up_x;
        send_data[2] = send_color_data.segment1[2].left_up_y;
        send_data[3] = send_color_data.segment1[2].right_down_x;
        send_data[4] = send_color_data.segment1[2].right_down_y;
        send_data[5] = send_color_data.segment1[2].center_x;
        send_data[6] = send_color_data.segment1[2].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }     
      break;

    case 0xA5:
      if((send_color_data.segment2[2].right_down_x - send_color_data.segment2[2].left_up_x) > 0){
        send_data[0] = send_color_data.segment2[2].id;
        send_data[1] = send_color_data.segment2[2].left_up_x;
        send_data[2] = send_color_data.segment2[2].left_up_y;
        send_data[3] = send_color_data.segment2[2].right_down_x;
        send_data[4] = send_color_data.segment2[2].right_down_y;
        send_data[5] = send_color_data.segment2[2].center_x;
        send_data[6] = send_color_data.segment2[2].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }     
      break;

    /* 蓝色块数据 */
    case 0xA6:
      if((send_color_data.segment1[3].right_down_x - send_color_data.segment1[3].left_up_x) > 0){
        send_data[0] = send_color_data.segment1[3].id;
        send_data[1] = send_color_data.segment1[3].left_up_x;
        send_data[2] = send_color_data.segment1[3].left_up_y;
        send_data[3] = send_color_data.segment1[3].right_down_x;
        send_data[4] = send_color_data.segment1[3].right_down_y;
        send_data[5] = send_color_data.segment1[3].center_x;
        send_data[6] = send_color_data.segment1[3].center_y;

      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }    
      break;
    case 0xA7:
      if((send_color_data.segment2[3].right_down_x - send_color_data.segment2[3].left_up_x) > 0){
        send_data[0] = send_color_data.segment2[3].id;
        send_data[1] = send_color_data.segment2[3].left_up_x;
        send_data[2] = send_color_data.segment2[3].left_up_y;
        send_data[3] = send_color_data.segment2[3].right_down_x;
        send_data[4] = send_color_data.segment2[3].right_down_y;
        send_data[5] = send_color_data.segment2[3].center_x;
        send_data[6] = send_color_data.segment2[3].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }      
      break;
    /* 紫色色块数据 */
    case 0xA8:
      if((send_color_data.segment1[4].right_down_x - send_color_data.segment1[4].left_up_x) > 0){
        send_data[0] = send_color_data.segment1[4].id;
        send_data[1] = send_color_data.segment1[4].left_up_x;
        send_data[2] = send_color_data.segment1[4].left_up_y;
        send_data[3] = send_color_data.segment1[4].right_down_x;
        send_data[4] = send_color_data.segment1[4].right_down_y;
        send_data[5] = send_color_data.segment1[4].center_x;
        send_data[6] = send_color_data.segment1[4].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }      
      break;
    case 0xA9:
      if((send_color_data.segment2[4].right_down_x - send_color_data.segment2[4].left_up_x) > 0){
        send_data[0] = send_color_data.segment2[4].id;
        send_data[1] = send_color_data.segment2[4].left_up_x;
        send_data[2] = send_color_data.segment2[4].left_up_y;
        send_data[3] = send_color_data.segment2[4].right_down_x;
        send_data[4] = send_color_data.segment2[4].right_down_y;
        send_data[5] = send_color_data.segment2[4].center_x;
        send_data[6] = send_color_data.segment2[4].center_y;
      }else{
        send_data[0] = 255;
        for(int i=1; i<7; i++){
          send_data[i] = 0;
        }
      }     
      break;
    }
    /* 打包发送色块数据 */
    Wire.slaveWrite(send_data, sizeof(send_data));
}

static void task_process_handler(void *arg)
{
  /* IIC初始化 */
  Wire.begin((uint8_t)I2C_SLAVE_ADDRESS, sdaPin, sclPin, i2cFrequency);
  /* 注册接收数据的回调函数 */
  Wire.onReceive(iic_receive);
  /* 注册请求数据的回调函数 */
  Wire.onRequest(iic_request);

  while (true)
  {

    if (xQueueReceive(xQueueResultI, &send_color_data, portMAX_DELAY))
    {
        // printf("center_x: red:%d  green:%d  blue:%d  purple:%d\r\n", send_color_data.segment2[0].center_x, \
        //                                                              send_color_data.segment2[1].center_x, \
        //                                                              send_color_data.segment2[2].center_x, \
        //                                                              send_color_data.segment2[3].center_x);
    }
  }
}

void register_iic_data_send(const QueueHandle_t result_i,
                            const QueueHandle_t result_o)
{
  xQueueResultI = result_i;
  xQueueResultO = result_o;

  xTaskCreatePinnedToCore(task_process_handler, TAG, 5 * 1024, NULL, 5, NULL, 0);
}