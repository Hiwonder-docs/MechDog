import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Initialize the ball launcher
mechdog.set_servo(9,1595,10)

# Main function
def main():
  # Delay function: the parameter is the delay time in seconds
  time.sleep(2)
  # "move()" function
  # Parameter 1: stride (unit: mm); If it is a positive value, the robot moves forward. If it is a negative value, the robot moves backward.
  # Parameter 2: turning angle (unit: degrees); If it is a positive value, the robot turns left. If it is a negative value, the robot turns right.
  mechdog.move(120,0)
  time.sleep(3)
  mechdog.move(0,0)
  time.sleep(0.5)
  mechdog.action_run("go_prone")
  time.sleep(1)
  mechdog.set_servo(9,450,30)
  time.sleep(1.5)
  mechdog.set_servo(9,1595,200)
  time.sleep(0.5)
  mechdog.set_default_pose()

# Execute the main function
main()








