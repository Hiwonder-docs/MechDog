import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()

#Initialize glowing ultrasonic object
i2c1 = Hiwonder_IIC.IIC(1)
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)
# Create buzzer object
beep = Hiwonder.Buzzer()

# Set MechDog's initial posture
mechdog.set_default_pose()
time.sleep(1)


# Main function
def main():
  # Glowing ultrasonic color setting function
  # Parameter 1: Light to set; 0 to set both lights, 1 to set light 1, 2 to set light 2
  # Parameters 2, 3, 4: Correspond to red, green, and blue color values
  i2csonar.setRGB(0,0xff,0xcc,0x33)
  # Enable self-balancing mode
  mechdog.homeostasis(True)
  time.sleep(2)
  # Check if still in self-balancing mode; exit the loop when leaving self-balancing mode
  while mechdog.read_homeostasis_status():
    time.sleep(0.1)
  i2csonar.setRGB(0,0x33,0x33,0xff)
  beep.playTone(800,100,True)
  
# Execute main function
main()

