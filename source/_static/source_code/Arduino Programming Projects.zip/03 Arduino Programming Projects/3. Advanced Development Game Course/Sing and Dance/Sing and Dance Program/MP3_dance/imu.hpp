#ifndef __IMU_H
#define __IMU_H

#include "iic_sensor_task.h"
#include <MPU6050.h>
#include "Hiwonder.h"

#define MPU6050_ADDRESS 0x68

class IMU{
  public:
    void begin();
    void get_angle(float* roll , float* pitch);
  private:
    uint8_t imu_type;
    MPU6050* accelgyro;
    void mpu6050_read_angle(void);
};

#endif //__IMU_H
