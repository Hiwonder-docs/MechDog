/**
 * @file imu_task.cpp
 * @author CuZn
 * 
 * @brief imu
 * 
 * @version 1.0
 * @date 2024-12-06
 * 
 * @copyright Copyright (c) 2024
 * 
 */
#include "imu.hpp"

#define TYPE_MPU6050 1
#define TYPE_QMI8658 2

int ax_offset, ay_offset, az_offset, gx_offset, gy_offset, gz_offset;
int16_t ax, ay, az;
int16_t gx, gy, gz;
float ax0, ay0, az0;
float gx0, gy0, gz0;
float ax1, ay1, az1;
float gx1, gy1, gz1;

float radianX;
float radianY;
float radianZ;
float radianX_last; //Final calculated tilt angle on the X-axis (radians)
float radianY_last; //Final calculated tilt angle on the Y-axis (radians)

void IMU::begin()
{
  imu_type = 0;
  if(qmi.begin(Wire, QMI8658_H_SLAVE_ADDRESS, SDA1, SCL1))
  {
    imu_type = TYPE_QMI8658;
    register_iic_sensor_task();
    Serial.println("QMI8658 init.");
  }else{
    imu_type = TYPE_MPU6050;
    accelgyro = new MPU6050(MPU6050_ADDRESS,&Wire);
    Wire.begin(SDA1,SCL1);
    accelgyro->initialize();
    accelgyro->setFullScaleGyroRange(3); //Set gyroscope full-scale range
    accelgyro->setFullScaleAccelRange(1); //Set accelerometer full-scale range
    delay(200);
    accelgyro->getMotion6(&ax, &ay, &az, &gx, &gy, &gz);  //Retrieve current axis data for calibration
    ax_offset = ax;
    ay_offset = ay;
    az_offset = az - 8192;
    gx_offset = gx;
    gy_offset = gy;
    gz_offset = gz;
    Serial.println("MPU6050 init.");
  }
}

void IMU::get_angle(float* roll , float* pitch)
{
  if(imu_type == TYPE_QMI8658)
  {
    *roll = filter.getRoll();
    *pitch = filter.getPitch();
  }else{
    mpu6050_read_angle();
    *roll = radianX_last;
    *pitch = radianY_last;
  }
}

void IMU::mpu6050_read_angle(void){
  accelgyro->getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  ax0 = ((float)(ax)) * 0.3 + ax0 * 0.7;  //Apply filtering to the accelerometer readings
  ay0 = ((float)(ay)) * 0.3 + ay0 * 0.7;
  az0 = ((float)(az)) * 0.3 + az0 * 0.7;
  ax1 = (ax0 - ax_offset) /  8192.0;  // Calibrate and convert to multiples of gravitational acceleration
  ay1 = (ay0 - ay_offset) /  8192.0;
  az1 = (az0 - az_offset) /  8192.0;

  gx0 = ((float)(gx)) * 0.3 + gx0 * 0.7;  //Apply filtering to the gyroscope readings
  gy0 = ((float)(gy)) * 0.3 + gy0 * 0.7;
  gz0 = ((float)(gz)) * 0.3 + gz0 * 0.7;
  gx1 = (gx0 - gx_offset);  //Calibrate gyroscope data
  gy1 = (gy0 - gy_offset);
  gz1 = (gz0 - gz_offset);


  //Complementary calculation of tilt angle on the X-axis
  radianX = atan2(ay1, az1);
  radianX_last = radianX * 180.0 / 3.1415926; //
  
  //Complementary calculation of tilt angle on the Y-axis
  radianY = atan2(ax1, az1);
  radianY_last = -radianY * 180.0 / 3.1415926; //
  
}
