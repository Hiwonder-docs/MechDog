import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize the MechDog object
mechdog = MechDog()


# Main function
def main():
  # Set the initial posture of MechDog
  mechdog.set_default_pose()
  # Delay function, with the parameter being the delay time (unit: seconds)
  time.sleep(2)
  mechdog.move(50,-16)
  time.sleep(5)
  mechdog.transform([0, 0, 1 * 20], [0, 0, 0], 1000)
  time.sleep(5)
  mechdog.transform([0, 0, -1 * 30], [0, 0, 0], 1000)
  time.sleep(5)
  mechdog.move(0,0)
  time.sleep(2)
  # Set the initial posture of MechDog
  mechdog.set_default_pose()

# Execute the main function
main()

