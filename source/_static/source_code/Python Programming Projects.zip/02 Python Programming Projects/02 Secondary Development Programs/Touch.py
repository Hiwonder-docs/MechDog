import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize the MechDog object
mechdog = MechDog()
# Button press flag
enter_flag = 0
# Action group number
action_num = 0
# Create button object
button2 = Hiwonder.Button(2)


# Set the initial posture of MechDog
mechdog.set_default_pose()
# Delay function, with the parameter being the delay time (unit: seconds)
time.sleep(1)

# Main function
def main():
  global enter_flag
  global action_num

  while True:
    # If button is pressed
    if (enter_flag==1):
      if (action_num==1):
        # Execute default action group: Sit
        mechdog.action_run("sit_dowm")
        time.sleep(1.5)
        action_num+=1
      elif (action_num==2):
        # Execute default action group: Lie down
        mechdog.action_run("go_prone")
        time.sleep(1.5)
        action_num+=1
      else:
        # Execute default action group: Stand
        mechdog.action_run("stand_four_legs")
        time.sleep(1.5)
        action_num = 1
      # Clear button press flag
      enter_flag = 0
    else:
      time.sleep(0.2)

# Button short press callback function
def on_extbutton_clicked():
  global enter_flag
  enter_flag = 1


# Register button short press callback function
button2.Clicked(on_extbutton_clicked)

# Execute the main function
main()
