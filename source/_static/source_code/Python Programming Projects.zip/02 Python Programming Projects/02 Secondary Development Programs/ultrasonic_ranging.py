import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Create matrix object
tm = Hiwonder.Digitaltube()
# Create IIC1 object
i2c1 = Hiwonder_IIC.IIC(1)
# Create glowy ultrasonic object
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)

# Set MechDog initial posture
mechdog.set_default_pose()
# Set matrix brightness to 4
tm.setBrightness(4)
# Delay function, parameter is the delay time (unit: seconds)
time.sleep(1)

# Ultrasonic distance measurement
distance = 0

# Main function
def main():
  global distance

  while True:
    distance = i2csonar.getDistance()
    tm.showNum(distance)
    if (distance<15):
      # Glowy ultrasonic color setting function
      # Parameter 1: Set light, 0 to set both lights, 1 to set light 1, 2 to set light 2；
      # Parameters 2, 3, 4: Correspond to red, green, and blue color values
      i2csonar.setRGB(0,0xff,0x00,0x00) # Set to red
    else:
      if (distance>40):
        i2csonar.setRGB(0,0x00,0x00,0x99) # Set to blue
      else:
        i2csonar.setRGB(0,0xfd,0xd0,0x00) # Set to yellow
    time.sleep(0.1)

# Execute main function
main()
