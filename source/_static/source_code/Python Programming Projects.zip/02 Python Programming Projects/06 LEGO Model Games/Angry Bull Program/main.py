import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Create I2C1 object
i2c1 = Hiwonder_IIC.IIC(1)
# Create glowy ultrasonic sensor object
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)


# Ultrasonic ranging
distance = 0
# Initialize servo

# Delay function: the parameter is the delay time in seconds
time.sleep(1)

# Main function
def main():
  global distance
  position_control()
  time.sleep(1)
  while True:
    # Obtain the distance detected by the ultrasonic sensor
    distance = i2csonar.getDistance()
    # If the distance is less than 18cm
    if (distance<18):
      # Function for setting the color of the ultrasonic sensor
      # Parameter 1: the number of the set light; 0: set 2 lights; 1: set 1 light; 2: set 2 lights
      # Parameters 2 to 4 corresponds the values of red, green, and blue respectively
      i2csonar.setRGB(0,255,0,0) # set to red
      mechdog.move(0,0)
      time.sleep(1)
      position_control(1000) # control the bull horn to lean forward
      time.sleep(0.1) 
      mechdog.set_pose([0,0,0],[0,20,0],300)  # set forward leaning posture
      time.sleep(0.4) 
      mechdog.move(80,0) 
      time.sleep(1) 
      mechdog.move(0,0) 
      time.sleep(1) 
      position_control()  # return the bull horn to the neutral position
      time.sleep(0.1) 
      mechdog.set_default_pose()  # return MechDog to neutral position
      time.sleep(2) 
      
    else: # If no obstacle is detected, MechDog keeps walking forward
      i2csonar.setRGB(0,0,0,255) 
      mechdog.move(120,0) 
    time.sleep(0.1)

def position_control(pos=0):
  mechdog.set_servo(9,1500+pos,10)
  mechdog.set_servo(10,1500-pos,10)

# Execute the main function
main()


