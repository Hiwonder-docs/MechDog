import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize the MechDog object
mechdog = MechDog()


# Main function
def main():
  # Set the initial posture of MechDog
  mechdog.set_default_pose()
  # Delay function, with the parameter being the delay time (unit: seconds)
  time.sleep(2)
  # Set the gait parameters as follows:
  # Parameter 1: Time for the toe to leave the ground
  # Parameter 2: Time for the toe to touch the ground
  # Parameter 3: Height of leg lift
  mechdog.set_gait_params(150,500,40)
  mechdog.move(50,0)
  time.sleep(5)
  mechdog.move(0,0)
  time.sleep(3)
  mechdog.set_gait_params(100,300,20)
  mechdog.move(50,0)
  time.sleep(5)
  mechdog.move(0,0)
  time.sleep(3)

# Execute the main function
main()
