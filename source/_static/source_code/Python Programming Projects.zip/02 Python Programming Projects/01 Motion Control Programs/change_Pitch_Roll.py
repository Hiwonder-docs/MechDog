import Hiwonder
import time
from HW_MechDog import MechDog

# Initialize the MechDog object
mechdog = MechDog()


# Main function
def main():
  # Set the initial posture of MechDog
  mechdog.set_default_pose()
  # Delay function, with the parameter being the delay time (unit: seconds)
  time.sleep(2)
  # Posture transformation function
  # Parameter 1: Translate the body (x, y, z axes)
  # Parameter 2: Rotate the body (around x, y, z axes)
  # Parameter 3: Transformation time
  mechdog.transform([0, 0, 0], [1 * 15, 0, 0], 500) # Rotate around the x-axis (Pitch)
  time.sleep(2)
  mechdog.transform([0, 0, 0], [-1 * 30, 0, 0], 1000)
  time.sleep(2)
  # Set the initial posture of MechDog
  mechdog.set_default_pose()
  time.sleep(2)
  mechdog.transform([0, 0, 0], [0, 1 * 15, 0], 500) # Rotate around the y-axis (Roll)
  time.sleep(2)
  mechdog.transform([0, 0, 0], [0, -1 * 30, 0], 1000)
  time.sleep(2)
  # Set the initial posture of MechDog
  mechdog.set_default_pose()
  time.sleep(2)

# Execute the main function
main()
