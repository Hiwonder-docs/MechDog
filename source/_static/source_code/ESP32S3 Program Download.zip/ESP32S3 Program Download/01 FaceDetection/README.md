# 人脸识别 IIC寄存器说明(face recognition I2C register instruction)

## 设备地址：0x52(device address: 0x52)



- ### 人脸识别(face recognition)

  | 寄存器地址(register address) |                   数据格式(data format):unsigned char                    |
  | :--------: | :----------------------------------------------------------: |
  |    0x01    | data[0]:人脸中心X轴坐标(X-axis coordinate of face center)<br/>data[1]:人脸中心Y轴坐标(Y-axis coordinate of face center)<br/>data[2]:检测框宽度(width of detection box)<br/>data[3]:检测框长度(length of detection box)<br/> |

  

  