import Hiwonder
import time
import Hiwonder_IIC
from HW_MechDog import MechDog

# Initialize MechDog object
mechdog = MechDog()
# Create I2C1 object
i2c1 = Hiwonder_IIC.IIC(1)
# Create glowy ultrasonic sensor object
i2csonar = Hiwonder_IIC.I2CSonar(i2c1)

# Ultrasonic ranging
distance = 0
# Initialize servo

# Delay function: the parameter is the delay time in seconds
time.sleep(1)

# Main function
def main():
  global distance
  # Initialize robotic arm
  mechdog.set_servo(9,1980,10)
  mechdog.set_servo(10,1500,10)
  time.sleep(1)
  while True:
    # Obtain the distance detected by the ultrasonic sensor
    distance = i2csonar.getDistance()
    # If the distance is less than 10cm
    if (distance<10):
      # Function for setting the color of the ultrasonic sensor
      # Parameter 1: the number of the set light; 0: set 2 lights; 1: set 1 light; 2: set 2 lights
      # Parameters 2 to 4 corresponds the values of red, green, and blue respectively
      i2csonar.setRGB(0,255,0,0) # set to red
      time.sleep(2)
      mechdog.set_servo(10,1800,1000) # grip
      time.sleep(2)
      mechdog.set_servo(9,1700,1000) # raise up the robotic arm
      time.sleep(2)
      mechdog.move(120,0)
      time.sleep(3)
      mechdog.move(0,0)
      time.sleep(2)
      mechdog.set_servo(9,1980,1000)# put the robotic arm down
      time.sleep(2)
      mechdog.set_servo(10,1500,1000)  # release
      time.sleep(2)
      
    else: # If no obstacle is detected
      i2csonar.setRGB(0,0,0,255) 
    time.sleep(0.1)

# Execute the main function
main()




