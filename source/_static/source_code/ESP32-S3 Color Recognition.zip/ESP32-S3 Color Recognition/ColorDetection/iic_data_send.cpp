#include "iic_data_send.hpp"
#include "Wire.h"

#define I2C_SLAVE_ADDRESS 0x53

static QueueHandle_t xQueueResultI = NULL;
static QueueHandle_t xQueueResultO = NULL;

static const char *TAG = "iic_data_send";
static const int sdaPin = 47;
static const int sclPin = 48;
static const uint32_t i2cFrequency = 100000;

static send_color_data_t color_data[5];

static uint8_t rec = 0xFF;
static uint8_t send_data[7] = {255};
static uint8_t list_send_data[7] = {255};

static void iic_receive(int len)
{
  while(Wire.available())
  {
    rec = Wire.read();
  }  
}

static void iic_request()
{
  /* RED */
  if(rec == 0xC0) 
  {
    if((color_data[0].right_down_x - color_data[0].left_up_x) > 0)
    {
      send_data[0] = color_data[0].id;
      send_data[1] = color_data[0].left_up_x;
      send_data[2] = color_data[0].left_up_y;
      send_data[3] = color_data[0].right_down_x;
      send_data[4] = color_data[0].right_down_y;
      send_data[5] = color_data[0].center_x;
      send_data[6] = color_data[0].center_y;
    }else{
      send_data[0] = 255;
      for(int i =1;i<7;i++){
        send_data[i] = 0;
      }
    }
  }
  /* YELLOW */
  else if(rec == 0xC1)
  {
    if((color_data[1].right_down_x - color_data[1].left_up_x) > 0){
      send_data[0] = color_data[1].id;
      send_data[1] = color_data[1].left_up_x;
      send_data[2] = color_data[1].left_up_y;
      send_data[3] = color_data[1].right_down_x;
      send_data[4] = color_data[1].right_down_y;
      send_data[5] = color_data[1].center_x;
      send_data[6] = color_data[1].center_y;
    }else{
      send_data[0] = 255;
      for(int i =1;i<7;i++){
        send_data[i] = 0;
      }
    }
  }
  /* GREEN */
  else if(rec == 0xC2)
  {
    if((color_data[2].right_down_x - color_data[2].left_up_x) > 0){
      send_data[0] = color_data[2].id;
      send_data[1] = color_data[2].left_up_x;
      send_data[2] = color_data[2].left_up_y;
      send_data[3] = color_data[2].right_down_x;
      send_data[4] = color_data[2].right_down_y;
      send_data[5] = color_data[2].center_x;
      send_data[6] = color_data[2].center_y;
    }else{
      send_data[0] = 255;
      for(int i =1;i<7;i++){
        send_data[i] = 0;
      }
    }
  }
  /* BLUE */
  else if(rec == 0xC3)
  {
    if((color_data[3].right_down_x - color_data[3].left_up_x) > 0){
      send_data[0] = color_data[3].id;
      send_data[1] = color_data[3].left_up_x;
      send_data[2] = color_data[3].left_up_y;
      send_data[3] = color_data[3].right_down_x;
      send_data[4] = color_data[3].right_down_y;
      send_data[5] = color_data[3].center_x;
      send_data[6] = color_data[3].center_y;
    }else{
      send_data[0] = 255;
      for(int i =1;i<7;i++){
        send_data[i] = 0;
      }
    }
  }
  /* PURPLE */
  else if(rec == 0xC4)
  {
    if((color_data[4].right_down_x - color_data[4].left_up_x) > 0){
      send_data[0] = color_data[4].id;
      send_data[1] = color_data[4].left_up_x;
      send_data[2] = color_data[4].left_up_y;
      send_data[3] = color_data[4].right_down_x;
      send_data[4] = color_data[4].right_down_y;
      send_data[5] = color_data[4].center_x;
      send_data[6] = color_data[4].center_y;
    }else{
      send_data[0] = 255;
      for(int i =1;i<7;i++){
        send_data[i] = 0;
      }
    }
  }
  /* ALL COLOR */
  else if(rec == 0xC5)
  {
    for(int i=0; i<5 ; i++){
      if((color_data[i].right_down_x - color_data[i].left_up_x) > 0){
        list_send_data[i] = i;
      }else{
        list_send_data[i] = 255;
      }
    }
    Wire.slaveWrite(list_send_data, sizeof(list_send_data));
  }

  if(rec != 0xC5){
    /* 发送色块数据 */
    Wire.slaveWrite(send_data, sizeof(send_data));
  }
}

static void task_process_handler(void *arg)
{
  /* IIC初始化 */
  Wire.begin((uint8_t)I2C_SLAVE_ADDRESS, sdaPin, sclPin, i2cFrequency);
  /* 注册接收数据的回调函数 */
  Wire.onReceive(iic_receive);
  /* 注册请求数据的回调函数 */
  Wire.onRequest(iic_request);

  while (true)
  {

    if (xQueueReceive(xQueueResultI, &color_data, portMAX_DELAY))
    {
    //  switch(rec){
    //   case 0x00:
    //     printf("red:%d",rec);
    //     break;
    //   case 0x01:
    //     printf("blue:%d",rec);
    //     break;
    //  }
    }
  }
}

void register_iic_data_send(const QueueHandle_t result_i,
                            const QueueHandle_t result_o)
{
  xQueueResultI = result_i;
  xQueueResultO = result_o;

  xTaskCreatePinnedToCore(task_process_handler, TAG, 4 * 1024, NULL, 5, NULL, 1);
}