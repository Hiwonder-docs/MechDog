import Hiwonder
import time
from HW_MechDog import MechDog

# Create brightness sensor object
adc = Hiwonder.LightSensor()
# Initialize the MechDog object
mechdog = MechDog()

# Delay function, with the parameter being the delay time (unit: seconds)
time.sleep(1)
# Light brightness threshold
Intensity_threshold = 100
# Read brightness value
brightness = 0  

# Main function
def main():
  global Intensity_threshold
  global brightness

  while True:
    # Read light intensity
    brightness = adc.read()
    # If brightness value is greater than the threshold
    if (brightness>=Intensity_threshold):
      # Execute standing action
      mechdog.action_run("stand_four_legs")
      time.sleep(2)
      # Walk
      mechdog.move(80,0)
      time.sleep(1)
      # While the brightness value is greater than the threshold, keep waiting; break the loop when it is less than the threshold
      while adc.read()>Intensity_threshold:
        time.sleep(0.1)
    else:
      # Stop
      mechdog.move(0,0)
      time.sleep(2)
      # Execute lying down action group
      mechdog.action_run("go_prone")
      time.sleep(2)
      # While the brightness value is less than the threshold, keep waiting; break the loop when it is greater than the threshold
      while adc.read()<Intensity_threshold:
        time.sleep(0.1)

# Execute the main function
main()
